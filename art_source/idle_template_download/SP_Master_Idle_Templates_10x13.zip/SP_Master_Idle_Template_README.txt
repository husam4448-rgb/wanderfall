SURVIVAL PARADISE - MASTER IDLE FRAME TEMPLATE v1

Source: fourth/last frame of the hand-drawn, pixel-exact four-frame walking sheet.
Pixel dimensions per sprite: 10 x 13; RGBA transparency.
Right: SP_Master_Idle_Right_10x13.png
Left: SP_Master_Idle_Left_10x13.png (exact horizontal mirror).

LOCKED RULES:
- Use these original pixels and grid as the baseline for NPC/player idle work.
- Do not extend legs, change proportions, interpolate, blur or generate extra pixels.
- Respect the black outlines; modify only pixels explicitly requested.
- Frame 4 is IDLE; frames 1, 2, and 3 of the corresponding original sheet are the walking progression.
- For future characters, design requested differences deliberately rather than unintentionally altering the baseline.
- Keep transparency and use nearest-neighbor scaling only.

The 10x13 frame originals were extracted without resampling from columns 31-40 (zero-based crop x=30..39) of the 40x13 sheets.
